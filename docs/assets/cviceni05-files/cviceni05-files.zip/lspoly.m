%zadani
n = 25;
x = linspace(0,5,n)'; %hodnoty x_i
f = 3*sin(4*x) + 4*x - exp(0.6*x); %hodnoty f(x_i)
k = 5;
%zde napiste reseni

